<?php
$email = $_POST['oemail'] ;
$newpass = $_POST['opass'] ;
$confirmpass = $_POST['ocpass'] ;

$conn = new mysqli("127.0.0.1", "root", "", "blood_donation", 3307);
if ($conn->connect_error) {
    echo "db_error";
    exit;
}


if ($newpass !== $confirmpass) {
    echo "password_mismatch";
    exit;
}

$stmt = $conn->prepare("SELECT id FROM organization WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo "email_not_found";
    exit;
}

$update = $conn->prepare("UPDATE organization SET password = ? WHERE email = ?");
$update->bind_param("ss", $newpass, $email);

if ($update->execute()) {
    echo "success";
} else {
    echo "error";
}
?>
