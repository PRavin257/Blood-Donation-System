<?php
session_start();
if (!isset($_SESSION['demail'])) {
    echo "not_logged_in";
    exit;
}
$fname = $_POST['fname'];
$mname = $_POST['mname'];
$lname = $_POST['lname'];
$dob = $_POST['dob'];
$gender = $_POST['gender'];
$address = $_POST['addr'];
$state = $_POST['state'];
$city = $_POST['city'];
$pin = $_POST['pin'];
$phone = $_POST['phno'];
$blood = $_POST['bld'];

$demail = $_SESSION['demail'];

$conn = new mysqli("127.0.0.1", "root", "", "blood_donation", 3307);

$check = $conn->prepare("SELECT email FROM donor WHERE phone = ? AND email != ?");
$check->bind_param("ss", $phone, $demail);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo "phone_exists";
    exit;
}


$stmt = $conn->prepare("
    UPDATE donor SET 
    dfname=?, dmname=?, dlname=?, dob=?, gender=?, blood_group=?, address=?, state=?, city=?, pincode=?, phone=? WHERE email=?");
$stmt->bind_param("ssssssssssss", $fname, $mname, $lname, $dob, $gender, $blood,$address, $state, $city, $pin, $phone,$demail);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error";
}
?>
