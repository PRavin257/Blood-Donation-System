<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['demail'])) {
    echo "not_logged_in";
    exit;
}

$email = $_SESSION['demail']; // Logged-in user's email
$oldpass = $_POST['opass'] ?? '';
$newpass = $_POST['npass'] ?? '';
$confirmpass = $_POST['cnpass'] ?? '';

$conn = new mysqli("127.0.0.1", "root", "", "blood_donation", 3307);
if ($conn->connect_error) {
    echo "db_error";
    exit;
}

// Step 1: Check old password matches
$stmt = $conn->prepare("SELECT password FROM donor WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($storedPass);
$stmt->fetch();

if ($stmt->num_rows === 0) {
    echo "email_not_found"; // Should never happen if session is valid
    exit;
}

if ($storedPass !== $oldpass) {
    echo "wrong_old_password";
    exit;
}

// Step 2: Check new and confirm password match
if ($newpass !== $confirmpass) {
    echo "password_mismatch";
    exit;
}

// Step 3: Update password
$update = $conn->prepare("UPDATE donor SET password = ? WHERE email = ?");
$update->bind_param("ss", $newpass, $email);

if ($update->execute()) {
    echo "success";
} else {
    echo "update_failed";
}
?>
