<?php
session_start();
if (isset($_SESSION['demail'])) {
    echo $_SESSION['demail'];
} else {
    echo "";
}
if (isset($_SESSION['oemail'])) {
    echo $_SESSION['oemail'];
} else {
    echo "";
}
if (isset($_SESSION['remail'])) {
    echo $_SESSION['remail'];
} else {
    echo "";
}

