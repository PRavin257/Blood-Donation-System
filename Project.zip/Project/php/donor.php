<?php
$firstname = $_POST['fname'];
$middlename = $_POST['mname'];
$lastname = $_POST['lname'];
$dob = $_POST['dob'];
$gender = $_POST['gender'];
$email = $_POST['email'];
$address = $_POST['addr'];
$state = $_POST['state'];
$city = $_POST['city'];
$pin = $_POST['pin'];
$phone = $_POST['phone'];
$blood = $_POST['bld'];
$password = $_POST['pass'];
$cpass = $_POST['cpass'];

if ($password !== $cpass) {
    echo "password_mismatch";
    exit;
}

$conn = new mysqli("127.0.0.1", "root", "", "blood_donation", 3307);

if ($conn->connect_error) {
    echo "db_error";
    exit;
}

// Email check
$stmt = $conn->prepare("SELECT 1 FROM donor WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo "email_exists";
    exit;
}

// Phone check
$stmt = $conn->prepare("SELECT 1 FROM donor WHERE phone = ?");
$stmt->bind_param("s", $phone);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo "phone_exists";
    exit;
}

// Insert
$stmt = $conn->prepare("INSERT INTO donor (dfname, dmname, dlname, dob, gender, email, address, state, city, pincode, phone, blood_group, password)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssssssssss", $firstname, $middlename, $lastname, $dob, $gender, $email, $address, $state, $city, $pin, $phone, $blood, $password);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error";
}
?>
