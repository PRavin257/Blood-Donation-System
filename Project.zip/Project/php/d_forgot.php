<?php
$email = $_POST['demail'] ;
$newpass = $_POST['dpass'] ;
$confirmpass = $_POST['dcpass'] ;

// DB connection
$conn = new mysqli("127.0.0.1", "root", "", "blood_donation", 3307);
if ($conn->connect_error) {
    echo "db_error";
    exit;
}

// Optional: Check if password and confirm match (redundant if handled in JS)
if ($newpass !== $confirmpass) {
    echo "password_mismatch";
    exit;
}

// Check if email exists
$stmt = $conn->prepare("SELECT id FROM donor WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo "email_not_found";
    exit;
}

// Update password
$update = $conn->prepare("UPDATE donor SET password = ? WHERE email = ?");
$update->bind_param("ss", $newpass, $email);

if ($update->execute()) {
    echo "success";
} else {
    echo "error";
}
?>
