<?php
$orgName = $_POST['OrgName'];
$email = $_POST['Email'];
$phone = $_POST['phone'];
$address = $_POST['OrgAdd'];
$state = $_POST['state'];
$city = $_POST['city'];
$pincode = $_POST['pincode'];
$password = $_POST['password'];
$confirmPassword = $_POST['confirmPassword'];

// Password match check
if ($password !== $confirmPassword) {
    echo "password_mismatch";
    exit;
}

// Database connection
$conn = new mysqli("127.0.0.1", "root", "", "blood_donation", 3307);

// Connection error check
if ($conn->connect_error) {
    echo "db_error";
    exit;
}

// Email check
$stmt = $conn->prepare("SELECT 1 FROM organization WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo "email_exists";
    exit;
}

// Phone check
$stmt = $conn->prepare("SELECT 1 FROM organization WHERE phone = ?");
$stmt->bind_param("s", $phone);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo "phone_exists";
    exit;
}

// Insert data
$stmt = $conn->prepare("INSERT INTO organization (org_name, email, phone, address, state, city, pincode, password)
VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssss", $orgName, $email, $phone, $address, $state, $city, $pincode, $password);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error";
}
?>
