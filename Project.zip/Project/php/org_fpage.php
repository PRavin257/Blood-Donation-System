<?php
session_start();


$email = $_SESSION['oemail'] ?? '';

$conn = new mysqli("127.0.0.1", "root", "", "blood_donation", 3307);

if ($conn->connect_error || $email === '') {
    echo json_encode(["error" => "Connection failed or session missing"]);
    exit;
}

$sql = "SELECT `A+`, `A-`, `B+`, `B-`, `AB+`, `AB-`, `O+`, `O-` FROM organization WHERE email = '$email'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $data = [
        "a_pos"  => $row['A+'],
        "a_neg"  => $row['A-'],
        "b_pos"  => $row['B+'],
        "b_neg"  => $row['B-'],
        "ab_pos" => $row['AB+'],
        "ab_neg" => $row['AB-'],
        "o_pos"  => $row['O+'],
        "o_neg"  => $row['O-']
    ];
    echo json_encode($data);
} else {
    echo json_encode(["error" => "No record found"]);
}

$conn->close();
