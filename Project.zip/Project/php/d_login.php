<?php
session_start();
$email = $_POST['email'] ;
$pass = $_POST['pass'];

$conn = new mysqli("127.0.0.1", "root", "", "blood_donation", 3307);
if ($conn->connect_error) {
    echo "db_error";
    exit;
}

// Check if email exists
$stmt = $conn->prepare("SELECT password FROM donor WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo "email_not_found";
    exit;
}

$stmt->bind_result($storedPass);
$stmt->fetch();

if ($storedPass !== $pass) {
    echo "wrong_password";
} else {
    echo "success";
    $_SESSION['demail']=$email;
}
?>
