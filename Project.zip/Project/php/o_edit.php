<?php
session_start();
if (!isset($_SESSION['oemail'])) {
    echo "not_logged_in";
    exit;
}
$name = $_POST['oname'];
$address = $_POST['addr'];
$state = $_POST['state'];
$city = $_POST['city'];
$pin = $_POST['pin'];
$phone = $_POST['phno'];



$oemail = $_SESSION['oemail'];

$conn = new mysqli("127.0.0.1", "root", "", "blood_donation", 3307);

$check = $conn->prepare("SELECT email FROM organization WHERE phone = ? AND email != ?");
$check->bind_param("ss", $phone, $oemail);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo "phone_exists";
    exit;
}


$stmt = $conn->prepare("
    UPDATE organization SET 
    org_name=?, address=?, state=?, city=?, pincode=?, phone=? WHERE email=?");
$stmt->bind_param("sssssss", $name,$address, $state, $city, $pin, $phone,$oemail);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error";
}
?>
