<?php
session_start();
if (!isset($_SESSION['oemail'])) {
    echo "not_logged_in";
    exit;
}

$blood = $_POST['bld'];
$num = $_POST['no'];
$oemail = $_SESSION['oemail'];



$allowed_blood_types = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
if (!in_array($blood, $allowed_blood_types)) {
    echo "invalid_blood_type";
    exit;
}


$column_map = [
    'A+' => 'A+',
    'A-' => 'A-',
    'B+' => 'B+',
    'B-' => 'B-',
    'AB+' => 'AB+',
    'AB-' => 'AB-',
    'O+' => 'O+',
    'O-' => 'O-',
];

$column = "`" . $column_map[$blood] . "`";


$conn = new mysqli("127.0.0.1", "root", "", "blood_donation", 3307);
if ($conn->connect_error) {
    echo "db_error";
    exit;
}

$sql = "UPDATE organization SET $column = $column + ? WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $num, $oemail);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error";
}
?>
