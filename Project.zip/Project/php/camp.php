<?php

session_start();
if (!isset($_SESSION['oemail'])) {
    echo "not_logged_in";
    exit;
}
$conn = new mysqli("127.0.0.1", "root", "", "blood_donation", 3307);

if ($conn->connect_error) {
    echo "db_error";
    exit;
}


$camp_name  = $_POST['cname'];
$address    = $_POST['addr'];
$state      = $_POST['state'];
$city       = $_POST['city'];
$pincode    = $_POST['pin'];
$email      = $_POST['email'];
$phone      = $_POST['phno'];
$start_date = $_POST['sdate'];
$end_date   = $_POST['edate'];

$org_email  = $_SESSION['oemail']; 


if (strtotime($end_date) < strtotime($start_date)) {
    echo "invalid_date";
    exit;
}

$check = $conn->prepare("SELECT email FROM organization WHERE phone = ? AND email != ?");
$check->bind_param("ss", $phone, $org_email);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo "phone_exists";
    exit;
}


// Prepare statement to insert data
$sql = "INSERT INTO camp (camp_name, address, state, city, pincode, email, phone, start_date, end_date, org_email) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssssssss", $camp_name, $address, $state, $city, $pincode, $email, $phone, $start_date, $end_date, $org_email);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error";
}
?>
