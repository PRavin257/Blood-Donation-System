 function showContent(num, btn) {

     const contents = document.querySelectorAll('.content');
     contents.forEach(el => el.classList.remove('active'));


     document.getElementById('box1-content' + num).classList.add('active');
     document.getElementById('box2-content' + num).classList.add('active');


     const buttons = document.querySelectorAll('.blood-btn .blood-button');
     buttons.forEach(b => b.classList.remove('active'));


     btn.classList.add('active');
 }


 window.onload = () => {
     const defaultBtn = document.querySelector('.blood-btn .blood-button');
     showContent(1, defaultBtn);
 };


 let slides = document.querySelectorAll(".carousel-slide");
 let dots = document.querySelectorAll(".dot");
 let current = 0;

 function showSlide(index) {
     slides.forEach(slide => slide.classList.remove("active"));
     dots.forEach(dot => dot.classList.remove("active"));
     slides[index].classList.add("active");
     dots[index].classList.add("active");
     current = index;
 }

 // Auto slide every 4 seconds
 setInterval(() => {
     current = (current + 1) % slides.length;
     showSlide(current);
 }, 10000);