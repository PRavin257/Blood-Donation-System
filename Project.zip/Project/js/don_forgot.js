document.addEventListener("DOMContentLoaded", function () {
    console.log("hello");
    
  const form = document.getElementById("forgotForm");

  form.addEventListener("submit", async function (e) {
    e.preventDefault();

    const email = document.getElementById("demail").value.trim();
    const pass = document.getElementById("dpass").value.trim();
    const cpass = document.getElementById("dcpass").value.trim();

    if (!email || !pass || !cpass) {
      alert("❌ Please fill all fields.");
      return;
    }

    if (pass !== cpass) {
      alert("❌ Passwords do not match.");
      return;
    }

    const formData = new FormData(this);
    const response = await fetch("./php/d_forgot.php", {
      method: "POST",
      body: formData,
    });

    const result = await response.text();
    console.log("Server Response:", result);

    if (result === "email_not_found") {
      alert("❌ Email not registered.");
    } else if (result === "success") {
      alert("✅ Password updated successfully!");
      window.location.href = "don_signin.html";
    } else {
      alert("❌ Something went wrong.");
    }
  });
});
