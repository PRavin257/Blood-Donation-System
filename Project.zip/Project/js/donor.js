document.getElementById("signupForm").addEventListener("submit", async function (e) {
  e.preventDefault();

  const formData = new FormData(this);

  const response = await fetch("./php/donor.php", {
    method: "POST",
    body: formData
  });

  const result = await response.text();

  if (result === "email_exists") {
    alert("Email is already registered!");
  } else if (result === "phone_exists") {
    alert("Phone number is already registered!");
  } else if (result === "password_mismatch") {
    alert("Passwords and Confirm Password are not same!");
  } else if (result === "success") {
    alert("✅ Registration successful!");
    window.location.href = "don_signin.html";
  } else {
    alert("Something went wrong!");
  }
});



