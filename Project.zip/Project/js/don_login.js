document.getElementById("signin").addEventListener("submit", async function (e) {
  e.preventDefault();

  const email = document.getElementById("semail").value.trim();
  const pass = document.getElementById("spass").value.trim();

  if (!email || !pass) {
    alert("❌ Please enter both email and password.");
    return;
  }

  const formData = new FormData(this);
  const response = await fetch("./php/d_login.php", {
    method: "POST",
    body: formData,
  });

  const result = await response.text();

  if (result === "email_not_found") {
    alert("❌ Email is not registered.");
  } else if (result === "wrong_password") {
    alert("❌ Incorrect password.");
  } else if (result === "success") {
    alert("✅ Login successful!");
    window.location.href = "./donor_fpage.html";
  } else {
    alert("❌ Something went wrong.");
  }
});
