document.getElementById("orgSignup").addEventListener("submit", async function (e) {
  e.preventDefault();

  const formData = new FormData(this);

  const response = await fetch("./php/org.php", {
    method: "POST",
    body: formData
  });

  const result = await response.text();

  if (result === "email_exists") {
    alert("Email is already registered!");
  } else if (result === "phone_exists") {
    alert("Phone number is already registered!");
  } else if (result === "password_mismatch") {
    alert("Passwords and Confirm Password do not match!");
  } else if (result === "success") {
    alert("✅ Registration successful!");
    window.location.href = "org_signin.html"; // Redirect to login
  } else if (result === "db_error") {
    alert("Database connection failed!");
  } else {
    alert("Something went wrong!");
    console.log(result); // debug if needed
  }
});
