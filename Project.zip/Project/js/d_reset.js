document.getElementById("reset").addEventListener("submit", async function (e) {
    e.preventDefault();


    const email = document.getElementById("opass").value.trim();
    const pass = document.getElementById("npass").value.trim();
    const cpass = document.getElementById("cnpass").value.trim();
    
    if (!email || !pass || !cpass) {
      alert("❌ Please fill all fields.");
      return;
    }

    const formData = new FormData(this);
    const response = await fetch("./php/d_reset.php", {
      method: "POST",
      body: formData
    });



    const result = await response.text();

    if (result === "success") {
      alert("✅ Password updated successfully!");
      window.location.href = "donor_fpage.html";
    } else if (result === "wrong_old_password") {
      alert("❌ Old password is incorrect.");
    } else if (result === "password_mismatch") {
      alert("❌ New and Confirm passwords do not match.");
    } else if (result === "not_logged_in") {
      alert("❌ Session expired. Please log in again.");
      window.location.href = "don_signin.html ";
    } else {
      alert("❌ Something went wrong. Please try again.");
      console.log("Error:", result);
    }
  });