document.getElementById("camp").addEventListener("submit", async function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    const response = await fetch("./php/camp.php", {
      method: "POST",
      body: formData
    });

     const startDate = new Date(document.getElementById("sdate").value);
    const endDate = new Date(document.getElementById("edate").value);

    if (endDate < startDate) {
        e.preventDefault(); 
        alert("End date must be greater than or equal to start date.");
    }


    const result = await response.text();

    if (result === "success") {
      alert("✅ Camp added successfully!");
      window.location.href = "org_fpage.html";
    } else if (result === "phone_exists") {
    alert("Phone number is already registered!");}
    else if(result === "invalid_date"){
        alert("End date must be greater than or equal to Start date");
    }
     else if (result === "not_logged_in") {
      alert("❌ Session expired. Please log in again.");
      window.location.href = "org_signin.html ";
    } else {
      alert("❌ Something went wrong. Please try again.");
      console.log("Error:", result);
    }
  });