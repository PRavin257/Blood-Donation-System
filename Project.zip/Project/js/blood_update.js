document.getElementById("update").addEventListener("submit", async function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    const response = await fetch("./php/blood_update.php", {
      method: "POST",
      body: formData
    });



    const result = await response.text();

    if (result === "success") {
      alert("✅ Stock updated successfully!");
      window.location.href = "org_fpage.html";
    } 
     else if (result === "not_logged_in") {
      alert("❌ Session expired. Please log in again.");
      window.location.href = "org_signin.html ";
    } else {
      alert("❌ Something went wrong. Please try again.");
      console.log("Error:", result);
    }
  });