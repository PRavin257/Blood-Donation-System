window.onload = async () => {
  const res = await fetch("./php/org_fpage.php");
  const data = await res.json();

  if (data.error) {
    alert(data.error);
    return;
  }

  document.getElementById("a_pos").textContent = data.a_pos;
  document.getElementById("a_neg").textContent = data.a_neg;
  document.getElementById("b_pos").textContent = data.b_pos;
  document.getElementById("b_neg").textContent = data.b_neg;
  document.getElementById("ab_pos").textContent = data.ab_pos;
  document.getElementById("ab_neg").textContent = data.ab_neg;
  document.getElementById("o_pos").textContent = data.o_pos;
  document.getElementById("o_neg").textContent = data.o_neg;
};
