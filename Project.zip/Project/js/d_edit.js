document.getElementById("edit").addEventListener("submit", async function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    const response = await fetch("./php/d_edit.php", {
      method: "POST",
      body: formData
    });



    const result = await response.text();

    if (result === "success") {
      alert("✅ Details updated successfully!");
      window.location.href = "donor_edit.html";
    } else if (result === "phone_exists") {
    alert("Phone number is already registered!");}
     else if (result === "not_logged_in") {
      alert("❌ Session expired. Please log in again.");
      window.location.href = "don_signin.html ";
    } else {
      alert("❌ Something went wrong. Please try again.");
      console.log("Error:", result);
    }
  });